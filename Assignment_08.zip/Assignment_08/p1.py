import numpy as np
def summation_unit(inputs, weights, bias=0):
    """Computes the weighted sum of inputs."""
    return np.dot(inputs, weights) + bias

# Activation functions
def step_function(x):
    return 1 if x >= 0 else 0

def bipolar_step(x):
    return 1 if x >= 0 else -1

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def tanh_function(x):
    return np.tanh(x)

def relu(x):
    return max(0, x)

def leaky_relu(x, alpha=0.01):
    return x if x > 0 else alpha * x

# Comparator for error calculation
def mean_squared_error(actual, predicted):
    """Computes Mean Squared Error (MSE) between actual and predicted values."""
    return np.mean((np.array(actual) - np.array(predicted)) ** 2)

def mean_absolute_error(actual, predicted):
    """Computes Mean Absolute Error (MAE) between actual and predicted values."""
    return np.mean(np.abs(np.array(actual) - np.array(predicted)))

def calculate_error(actual, predicted, method='mse'):
    """Calculates error using the specified method (MSE or MAE)."""
    if method == 'mse':
        return mean_squared_error(actual, predicted)
    elif method == 'mae':
        return mean_absolute_error(actual, predicted)
    else:
        raise ValueError("Unsupported error calculation method. Use 'mse' or 'mae'.")

