import numpy as np
from p1 import sigmoid  # sigmoid from your p1.py

def sigmoid_derivative(x):
    return x * (1 - x)

# XOR gate data
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
y = np.array([[0], [1], [1], [0]])  # XOR outputs

# Parameters
np.random.seed(42)
input_size = 2
hidden_size = 2
output_size = 1
alpha = 0.05  # Learning rate

# Weight & bias initialization
V = np.random.uniform(-1, 1, (input_size, hidden_size))
W = np.random.uniform(-1, 1, (hidden_size, output_size))
bias_hidden = np.zeros((1, hidden_size))
bias_output = np.zeros((1, output_size))

# Training loop
epochs = 10000
for epoch in range(epochs):
    # Forward pass
    hidden_input = np.dot(X, V) + bias_hidden
    hidden_output = sigmoid(hidden_input)
    
    final_input = np.dot(hidden_output, W) + bias_output
    final_output = sigmoid(final_input)
    
    # Backpropagation
    error = y - final_output
    d_output = error * sigmoid_derivative(final_output)
    
    error_hidden = d_output.dot(W.T)
    d_hidden = error_hidden * sigmoid_derivative(hidden_output)
    
    # Weight updates
    W += hidden_output.T.dot(d_output) * alpha
    bias_output += np.sum(d_output, axis=0, keepdims=True) * alpha
    
    V += X.T.dot(d_hidden) * alpha
    bias_hidden += np.sum(d_hidden, axis=0, keepdims=True) * alpha

# Output results
print("Trained Output:\n", np.round(final_output))
print("\nFinal Output (probabilities):\n", final_output)
