from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelBinarizer
import numpy as np


X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
# XOR gate output: 0 → class 0, 1 → class 1
y = np.array([0, 1, 1, 0])  # XOR truth table

# One-hot encoding: 0 → [1, 0], 1 → [0, 1]
lb = LabelBinarizer()
y_onehot = lb.fit_transform(y)

# Train MLP
clf_xor = MLPClassifier(hidden_layer_sizes=(2,), activation='logistic', learning_rate_init=0.05, max_iter=10000)
clf_xor.fit(X, y)

# Predict
pred_xor = clf_xor.predict(X)
pred_proba_xor = clf_xor.predict_proba(X)

print("\nXOR Predictions:", pred_xor)
print("XOR Output Probabilities:\n", np.round(pred_proba_xor, 3))
