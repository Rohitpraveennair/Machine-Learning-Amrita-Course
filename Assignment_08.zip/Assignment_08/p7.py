import numpy as np
from p6 import X, y, scaler
from sklearn.metrics import confusion_matrix, accuracy_score
import matplotlib.pyplot as plt

# Convert labels to binary values
unique_labels = np.unique(y)
if len(unique_labels) != 2:
    raise ValueError(f"Expected binary classification but found labels: {unique_labels}")

y_binary = np.where(y == unique_labels[1], 1, 0)  # Ensures correct mapping

# Check label distribution
print("Label distribution:", np.bincount(y_binary))

# Add a bias column
X_bias = np.c_[np.ones(X.shape[0]), X]

# Compute pseudo-inverse
X_pinv = np.linalg.pinv(X_bias)
weights_pinv = X_pinv @ y_binary

# Predict using pseudo-inverse
y_pred_pinv = X_bias @ weights_pinv
y_pred_pinv = (y_pred_pinv >= 0.5).astype(int)

# Debugging outputs
print("\n--- Debugging ---")
print("Computed weights:", weights_pinv)
print("Unique predictions:", np.unique(y_pred_pinv))

# Check for degenerate output
if len(np.unique(y_pred_pinv)) == 1:
    print("Warning: Pseudo-inverse produced only one class.")

# Performance evaluation
accuracy = accuracy_score(y_binary, y_pred_pinv)
conf_matrix = confusion_matrix(y_binary, y_pred_pinv)

print("\n--- Matrix Pseudo-Inverse Results ---")
print("Accuracy:", accuracy)
print("Confusion Matrix:\n", conf_matrix)

# Plot confusion matrix
plt.matshow(conf_matrix, cmap=plt.cm.Blues, alpha=0.7)
plt.colorbar()
plt.title("Pseudo-Inverse Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

