import numpy as np
from p1 import sigmoid

def sigmoid_derivative(x):
    return x * (1 - x)

# XOR with one-hot encoding
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

# XOR target with one-hot encoding
y = np.array([
    [1, 0],
    [0, 1],
    [0, 1],
    [1, 0]
])

# Parameters
np.random.seed(42)
input_size = 2
hidden_size = 2
output_size = 2
alpha = 0.05

# Weight & bias initialization
V = np.random.uniform(-1, 1, (input_size, hidden_size))  # input to hidden
W = np.random.uniform(-1, 1, (hidden_size, output_size))  # hidden to output
bias_hidden = np.zeros((1, hidden_size))
bias_output = np.zeros((1, output_size))

# Training
epochs = 10000
for epoch in range(epochs):
    # Forward pass
    hidden_input = np.dot(X, V) + bias_hidden
    hidden_output = sigmoid(hidden_input)
    
    final_input = np.dot(hidden_output, W) + bias_output
    final_output = sigmoid(final_input)
    
    # Backward pass
    error = y - final_output
    d_output = error * sigmoid_derivative(final_output)
    
    error_hidden = d_output.dot(W.T)
    d_hidden = error_hidden * sigmoid_derivative(hidden_output)
    
    # Update weights and biases
    W += hidden_output.T.dot(d_output) * alpha
    bias_output += np.sum(d_output, axis=0, keepdims=True) * alpha
    
    V += X.T.dot(d_hidden) * alpha
    bias_hidden += np.sum(d_hidden, axis=0, keepdims=True) * alpha

# Predictions
print("For XOR: \n")
print("Trained Output (probabilities):\n", np.round(final_output, 3))
print("\nClass Predictions:")
print(np.round(final_output))
