import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from p1 import step_function,sigmoid,relu,bipolar_step
# Load dataset
df = pd.read_csv("player_aggregated_stats_cleaned.csv")

# Selecting relevant features and target
feature_columns = ['Runs Scored', 'Strike Rate']  # Example feature selection
target_column = 'Consistency Score'

df = df.fillna(0)  # Handle missing values

# Normalize target for binary classification (threshold-based)
df['Target'] = df[target_column].apply(lambda x: 1 if x >= df[target_column].median() else -1)

# Extract features and target
X = df[feature_columns].values
y = df['Target'].astype(float).values.reshape(-1, 1)  # Ensure y is float

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)



# Initialize weights and bias
weights = np.random.randn(X.shape[1]) * 0.01  # Better initialization
bias = np.random.randn() * 0.01  # Small random bias
alpha = 0.05  # Learning rate
max_epochs = 200  # Reduced iterations for faster testing
convergence_threshold = 0.002

def perceptron_learning(X, y, activation_function, weights, bias, alpha, max_epochs):
    errors = []
    for epoch in range(max_epochs):
        total_error = 0
        for i in range(len(X)):
            summation = np.dot(X[i], weights) + bias
            prediction = activation_function(summation)
            error = y[i] - prediction
            total_error += error ** 2  # Sum of squared error
            
            # Adjust weight updates for different activation functions
            if activation_function == sigmoid:
                gradient = error * prediction * (1 - prediction)  # Sigmoid gradient
            elif activation_function == relu:
                gradient = error * (1 if summation > 0 else 0)  # ReLU derivative
            else:
                gradient = error  # Step and Bipolar Step use direct error
            
            weights += alpha * gradient * X[i]
            bias += alpha * gradient
        errors.append(total_error)
        print(f"Epoch {epoch+1}: Total Error = {total_error}")
        if total_error <= convergence_threshold:
            print(f"Converged at epoch {epoch+1}")
            break
    return weights, bias, errors

# Compare activation functions
activation_functions = {
    'Step': step_function,
    'Bipolar Step': bipolar_step,
    'Sigmoid': sigmoid,
    'ReLU': relu
}

results = {}

for name, func in activation_functions.items():
    print(f"Training with {name} activation function...")
    final_weights, final_bias, errors = perceptron_learning(X, y, func, weights.copy(), bias, alpha, max_epochs)
    results[name] = len(errors)
    plt.plot(range(1, len(errors) + 1), errors, marker='o', linestyle='-', label=name)

# Plot epochs vs. sum-square error
plt.xlabel('Epochs')
plt.ylabel('Sum-Squared Error')
plt.title('Perceptron Learning Convergence on Dataset')
plt.legend()
plt.show()

# Print results
print("Iterations to converge:", results)
print("Final weights:", final_weights)
print("Final bias:", final_bias)