import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
df = pd.read_csv("player_aggregated_stats_cleaned.csv")

# Feature selection
feature_columns = ['Runs Scored', 'Strike Rate','Balls Faced']
target_column = 'Consistency Score'

# Fill missing values
df = df.fillna(0)

# Create binary target
df['Target'] = df[target_column].apply(lambda x: 1 if x >= df[target_column].median() else 0)

# Extract features and target
X = df[feature_columns].values
y = df['Target'].values  # 0 or 1

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train MLPClassifier (Sigmoid → logistic activation)
mlp = MLPClassifier(hidden_layer_sizes=(10,10), activation='logistic', learning_rate_init=0.05,
                    max_iter=1000, random_state=42)
mlp.fit(X_train, y_train)

# Predict and evaluate
y_pred = mlp.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))
