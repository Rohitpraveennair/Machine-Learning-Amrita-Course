import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from p1 import *

# Generate random input dataset
np.random.seed(42)
X = np.random.randint(0, 2, size=(100, 2))  # 100 samples with binary inputs
y = np.logical_xor(X[:, 0], X[:, 1]).astype(int)  # XOR output


# Initialize weights and bias
weights = np.array([0.2, -0.75])
bias = 10
learning_rates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
max_epochs = 1000
convergence_threshold = 0.002

def perceptron_learning(X, y, activation_function, weights, bias, alpha, max_epochs):
    errors = []
    for epoch in range(max_epochs):
        total_error = 0
        for i in range(len(X)):
            summation = np.dot(X[i], weights) + bias
            prediction = activation_function(summation)
            error = y[i] - prediction
            total_error += error ** 2
            
            gradient = error
            weights += alpha * gradient * X[i]
            bias += alpha * gradient
        errors.append(total_error)
        if total_error <= convergence_threshold:
            return epoch + 1
    print("Did not converge within 1000 iterations (error > 0.02)")
    return max_epochs

# Compare learning rates
convergence_epochs = {}
for alpha in learning_rates:
    print(f"Training with learning rate {alpha}...")
    epochs_needed = perceptron_learning(X, y, step_function, weights.copy(), bias, alpha, max_epochs)
    convergence_epochs[alpha] = epochs_needed

# Plot learning rate vs. iterations to converge
plt.plot(list(convergence_epochs.keys()), list(convergence_epochs.values()), marker='o', linestyle='-')
plt.xlabel('Learning Rate')
plt.ylabel('Iterations to Converge')
plt.title('Effect of Learning Rate on Convergence (XOR)')
plt.show()

# Print results
print("Learning rate vs. iterations needed for convergence:", convergence_epochs)
