import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

df=pd.read_csv("transaction_data.csv")

# Extract features and target
X = df[["Candies", "Mangoes", "Milk Packets", "Payment"]].values
y = df["High Value Tx"].values

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Sigmoid function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Initialize weights and bias
weights = np.random.randn(X.shape[1])
bias = np.random.randn()
alpha = 0.5  # Best-suited learning rate
max_epochs = 1000
convergence_threshold = 0.002

def perceptron_learning(X, y, activation_function, weights, bias, alpha, max_epochs):
    errors = []
    for epoch in range(max_epochs):
        total_error = 0
        for i in range(len(X)):
            summation = np.dot(X[i], weights) + bias
            prediction = activation_function(summation)
            error = y[i] - prediction
            total_error += error ** 2
            
            gradient = error * prediction * (1 - prediction)  # Sigmoid derivative
            weights += alpha * gradient * X[i]
            bias += alpha * gradient
        errors.append(total_error)
        if total_error <= convergence_threshold:
            print(f"Converged at epoch {epoch+1}")
            return epoch + 1, errors
    print("Did not converge within 1000 iterations (error > 0.02)")
    return max_epochs, errors

# Train model
epochs_needed, errors = perceptron_learning(X, y, sigmoid, weights, bias, alpha, max_epochs)

# Plot epochs vs. sum-square error
plt.plot(range(1, len(errors) + 1), errors, marker='o', linestyle='-')
plt.xlabel('Epochs')
plt.ylabel('Sum-Squared Error')
plt.title('Perceptron Learning Convergence with Sigmoid')
plt.show()

print("Epochs Needed: ",epochs_needed)
print("Final weights:", weights)
print("Final bias:", bias)
