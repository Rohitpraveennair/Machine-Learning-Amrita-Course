import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from p1 import *
# Load dataset
df = pd.read_csv("player_aggregated_stats_cleaned.csv")

# Selecting relevant features and target
feature_columns = ['Runs Scored', 'Strike Rate']  # Example feature selection
target_column = 'Consistency Score'

df = df.fillna(0)  # Handle missing values

# Normalize target for binary classification (threshold-based)
df['Target'] = df[target_column].apply(lambda x: 1 if x >= df[target_column].median() else -1)

# Extract features and target
X = df[feature_columns].values
y = df['Target'].astype(float).values.reshape(-1, 1)  # Ensure y is float

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)



# Initialize weights and bias
weights = np.array([0.2, -0.75])  # Given initial weights
bias = 10  # Given initial bias
learning_rates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
max_epochs = 1000  # Max iterations
convergence_threshold = 0.002

def perceptron_learning(X, y, activation_function, weights, bias, alpha, max_epochs):
    errors = []
    for epoch in range(max_epochs):
        total_error = 0
        for i in range(len(X)):
            summation = np.dot(X[i], weights) + bias
            prediction = activation_function(summation)
            error = y[i] - prediction
            total_error += error ** 2  # Sum of squared error
            
            gradient = error  # Default update rule
            weights += alpha * gradient * X[i]
            bias += alpha * gradient
        errors.append(total_error)
        if total_error <= convergence_threshold:
            return epoch + 1  # Return convergence epoch
    print("Did not converge within 1000 iterations (error > 0.02)")
    return max_epochs  # If not converged, return max epochs

# Compare learning rates
convergence_epochs = {}
for alpha in learning_rates:
    print(f"Training with learning rate {alpha}...")
    epochs_needed = perceptron_learning(X, y, step_function, weights.copy(), bias, alpha, max_epochs)
    convergence_epochs[alpha] = epochs_needed

# Plot learning rate vs. iterations to converge
plt.plot(list(convergence_epochs.keys()), list(convergence_epochs.values()), marker='o', linestyle='-')
plt.xlabel('Learning Rate')
plt.ylabel('Iterations to Converge')
plt.title('Effect of Learning Rate on Convergence')
plt.show()

# Print results
print("Learning rate vs. iterations needed for convergence:", convergence_epochs)
