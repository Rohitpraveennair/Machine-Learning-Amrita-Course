import numpy as np
import pandas as pd
from collections import Counter


# 📌 Function to calculate entropy
def entropy(y):
    """Calculate entropy of a given target column."""
    value_counts = y.value_counts(normalize=True)
    return -np.sum(value_counts * np.log2(value_counts + 1e-9))  # Prevent log(0)


# 📌 Function to calculate Information Gain
def information_gain(df, feature, target):
    """Compute information gain for a given feature."""
    total_entropy = entropy(df[target])  # Entropy before splitting

    values = df[feature].unique()
    weighted_entropy = sum(
        (len(df[df[feature] == v]) / len(df)) * entropy(df[df[feature] == v][target])
        for v in values
    )

    return total_entropy - weighted_entropy  # Information Gain formula


# 📌 Function for binning numerical features
def binning(df, column, bins=4, binning_type='equal-width'):
    """Convert continuous numerical features to categorical using binning."""
    df = df.copy()

    if binning_type == 'equal-width':
        df[column] = pd.cut(df[column], bins=bins, labels=False, duplicates='drop')
    elif binning_type == 'equal-frequency':
        df[column] = pd.qcut(df[column], q=bins, labels=False, duplicates='drop')
    else:
        raise ValueError("Invalid binning type. Choose 'equal-width' or 'equal-frequency'.")

    return df


# 📌 Decision Tree Class
class DecisionTree:
    def __init__(self, min_samples_split=2, max_depth=None):
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth
        self.tree = None

    def fit(self, df, target, depth=0):
        """Recursively build the decision tree."""
        # 🛑 BASE CASES: Stop splitting if conditions met
        if len(df) < self.min_samples_split or (self.max_depth is not None and depth >= self.max_depth):
            return df[target].mode()[0]  # Return majority class

        # Identify potential features to split
        features = [col for col in df.columns if col != target]

        # 🛑 If no features left to split, return majority class
        if not features:
            return df[target].mode()[0]

        # Compute Information Gain for each feature
        info_gains = {feature: information_gain(df, feature, target) for feature in features}

        # Select the best feature to split on
        best_feature = max(info_gains, key=info_gains.get)

        # 🛑 If no significant gain, return majority class
        if info_gains[best_feature] == 0:
            return df[target].mode()[0]

        # Create the tree structure
        tree = {best_feature: {}}
        for value in df[best_feature].unique():
            subset = df[df[best_feature] == value]

            # 🛑 Prevent infinite recursion if subset has same target values
            if subset.empty or subset[target].nunique() == 1:
                tree[best_feature][value] = df[target].mode()[0]
            else:
                tree[best_feature][value] = self.fit(subset, target, depth + 1)

        return tree

    def train(self, df, target):
        """Train the decision tree on the dataset."""
        self.tree = self.fit(df, target)

    def predict_one(self, tree, row):
        """Predict a single instance using the trained tree."""
        if not isinstance(tree, dict):
            return tree  # Leaf node

        feature = next(iter(tree))  # Get first feature
        value = row.get(feature, None)

        if value not in tree[feature]:
            # 🛑 Fix: Return the most common class if value not in training data
            leaf_values = [v for v in tree[feature].values() if not isinstance(v, dict)]
            return Counter(leaf_values).most_common(1)[0][0] if leaf_values else None

        return self.predict_one(tree[feature][value], row)

    def predict(self, df):
        """Predict multiple instances."""
        return df.apply(lambda row: self.predict_one(self.tree, row), axis=1)

    def print_tree(self, tree=None, depth=0):
        """Recursively print the decision tree."""
        if tree is None:
            tree = self.tree  # Start from root

        if not isinstance(tree, dict):  # Leaf node
            print("  " * depth + f"Leaf: {tree}")
            return

        for feature, branches in tree.items():
            print("  " * depth + f"[Feature: {feature}]")
            for value, subtree in branches.items():
                print("  " * (depth + 1) + f"→ {value}")
                self.print_tree(subtree, depth + 2)


# 📌 RUN THE MODULE
if __name__ == "__main__":
    # Load dataset
    try:
        df = pd.read_csv("player_aggregated_stats.csv")
    except FileNotFoundError:
        print("Error: File 'player_aggregated_stats.csv' not found.")
        exit()

    target_column = "Consistency Score"

    # Identify numerical features (excluding the target column)
    numerical_features = [col for col in df.columns if df[col].dtype in ['int64', 'float64'] and col != target_column]

    # Apply binning to numerical features
    for feature in numerical_features:
        df = binning(df, column=feature, bins=4, binning_type='equal-width')

    # Split into training & testing (80%-20%)
    train_df = df.sample(frac=0.8, random_state=42)
    test_df = df.drop(train_df.index)

    # Print training and testing samples
    print("\nTraining Dataset:\n", train_df.head())
    print("\nTesting Dataset:\n", test_df.head())

    # Train Decision Tree
    dt = DecisionTree(min_samples_split=2, max_depth=5)
    dt.train(train_df, target_column)

    # ✅ Print Decision Tree in a structured format
    print("\nTrained Decision Tree Structure:")
    dt.print_tree()

    # Make Predictions on Test Data
    test_predictions = dt.predict(test_df)
    print("\nPredictions on Test Data:")
    print(test_predictions.head(10))
