import pandas as pd


def binning(df, column, bins=4, binning_type='equal-width'):
    df = df.copy()

    if binning_type == 'equal-width':
        df[column + "_equal_width"] = pd.cut(df[column], bins=bins, labels=False, duplicates='drop')
    elif binning_type == 'equal-frequency':
        df[column + "_equal_freq"] = pd.qcut(df[column], q=bins, labels=False, duplicates='drop')
    else:
        raise ValueError("Invalid binning type. Choose 'equal-width' or 'equal-frequency'.")

    return df

if __name__ == "__main__":
    # Load dataset
    try:
        df = pd.read_csv("player_aggregated_stats.csv")
    except FileNotFoundError:
        print("Error: File 'player_aggregated_stats.csv' not found.")
        exit()

    target_column = "Consistency Score"

    # Identify numerical features (excluding the target column)
    numerical_features = [col for col in df.columns if df[col].dtype in ['int64', 'float64'] and col != target_column]

    # Apply equal-width binning and print bins
    print("\nEqual-Width Binning Results:")
    for feature in numerical_features:
        df = binning(df, column=feature, bins=4, binning_type='equal-width')
        print(df[[feature, feature + "_equal_width"]].head(10))  # Print first 10 rows for comparison

    # Apply equal-frequency binning and print bins
    print("\nEqual-Frequency Binning Results:")
    for feature in numerical_features:
        df = binning(df, column=feature, bins=4, binning_type='equal-frequency')
        print(df[[feature, feature + "_equal_freq"]].head(10))  # Print first 10 rows for comparison
