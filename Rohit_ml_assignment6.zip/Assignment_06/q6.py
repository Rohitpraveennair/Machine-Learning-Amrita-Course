import matplotlib.pyplot as plt
import pandas as pd
from sklearn.tree import DecisionTreeClassifier, plot_tree

# Load dataset
df = pd.read_csv("player_aggregated_stats.csv")

# Define target column
target_column = "Consistency Score"

# Convert numerical target into categorical bins (e.g., "Low", "Medium", "High")
df[target_column] = pd.qcut(df[target_column], q=3, labels=["Low", "Medium", "High"])

# Identify categorical and numerical features
categorical_features = df.select_dtypes(include=['object']).columns.tolist()
numerical_features = df.select_dtypes(include=['int64', 'float64']).columns.tolist()

# Ensure target column is not in numerical_features
if target_column in numerical_features:
    numerical_features.remove(target_column)

# Convert categorical features using one-hot encoding
df = pd.get_dummies(df, columns=categorical_features, drop_first=True)  

# Get the updated feature list
features = [col for col in df.columns if col != target_column]

# Train Decision Tree Classifier (with a limited depth for readability)
clf = DecisionTreeClassifier(max_depth=4, criterion="entropy")  # Try `max_depth=3` if still too complex
clf.fit(df[features], df[target_column])

# Plot the tree with better readability
plt.figure(figsize=(20, 12))  # Increase size for better visualization
plot_tree(
    clf, 
    feature_names=features, 
    class_names=["Low", "Medium", "High"], 
    filled=True, 
    rounded=True, 
    fontsize=10  # Adjust font size for readability
)

plt.title("Decision Tree for Player Consistency Score", fontsize=14)
plt.show()
