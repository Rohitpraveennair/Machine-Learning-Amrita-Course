import pandas as pd
from math import log2

def equal_width_binning(data, column, bins=4):
    binned_data = pd.cut(data[column], bins=bins, labels=False, include_lowest=True)
    return binned_data

def calculate_entropy(data):
    # Calculate entropy of a dataset.
    value_counts = data.value_counts(normalize=True)
    entropy = -sum(p * log2(p) for p in value_counts if p > 0)
    return entropy

def calculate_gini_index(data):
    value_counts = data.value_counts(normalize=True)
    gini_index = 1 - sum(p ** 2 for p in value_counts)
    return gini_index

if __name__ == "__main__":
    # Load dataset
    df = pd.read_csv("player_aggregated_stats.csv")

    # Specify numeric column for binning
    numeric_column = 'Dot Ball Percentage'

    # Apply equal width binning
    df['binned'] = equal_width_binning(df, numeric_column)

    # Calculate entropy
    entropy_value = calculate_entropy(df['binned'])
    print(f"Entropy of binned data: {entropy_value}")

    # Calculate Gini Index
    gini_value = calculate_gini_index(df['binned'])
    print(f"Gini Index of binned data: {gini_value}")