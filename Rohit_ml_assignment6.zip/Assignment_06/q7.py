import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.inspection import DecisionBoundaryDisplay
from sklearn.preprocessing import StandardScaler

# Load dataset (Replace with actual file)
df = pd.read_csv("player_aggregated_stats.csv")

# Select 2 features for classification
features = ["Runs Scored", "Strike Rate"]
target_column = "Consistency Score"  # Adjust according to your dataset

# 🔍 Ensure Strike Rate is Valid
df["Strike Rate"] = df["Strike Rate"].clip(0, 600)  # No negative or extreme values
df.dropna(subset=features + [target_column], inplace=True)

# Convert categorical target if necessary
df[target_column] = df[target_column].astype("category").cat.codes

# Standardize the features for better separation
scaler = StandardScaler()
df[features] = scaler.fit_transform(df[features])

# Train a Decision Tree with controlled depth
clf = DecisionTreeClassifier(max_depth=3, min_samples_split=10, min_samples_leaf=5)
clf.fit(df[features], df[target_column])

# Define plot boundaries
fig, ax = plt.subplots(figsize=(8, 6))
DecisionBoundaryDisplay.from_estimator(
    clf, df[features], cmap=plt.cm.RdYlBu, response_method="predict", ax=ax, alpha=0.8
)

# Scatter plot of actual data points
scatter = ax.scatter(
    df[features[0]], df[features[1]], c=df[target_column], cmap=plt.cm.RdYlBu, edgecolor="black"
)

# Improve plot aesthetics
ax.set_xlabel("Runs Scored (Scaled)")
ax.set_ylabel("Strike Rate (Scaled)")
ax.set_title("Improved Decision Tree Boundary")
ax.grid(True, linestyle="--", linewidth=0.5)

# Add clear legend
legend_labels = {0: "Low", 1: "Medium", 2: "High"}
handles = [
    plt.Line2D([0], [0], marker="o", color="w", markerfacecolor=plt.cm.RdYlBu(i / 2), markersize=8)
    for i in range(3)
]
plt.legend(handles, legend_labels.values(), title="Performance", loc="upper left")

plt.show()
