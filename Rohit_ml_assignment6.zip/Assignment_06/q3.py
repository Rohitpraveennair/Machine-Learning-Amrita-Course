import numpy as np
import pandas as pd

def entropy(y):
    value_counts = y.value_counts(normalize=True)  # Get probability of each class
    return -np.sum(value_counts * np.log2(value_counts + 1e-9))  # Prevent log(0)

def information_gain(df, feature, target):
    """Calculate Information Gain for a given feature."""
    total_entropy = entropy(df[target])  # Entropy before splitting

    # Compute weighted entropy after splitting by feature
    values = df[feature].unique()
    weighted_entropy = sum(
        (len(df[df[feature] == v]) / len(df)) * entropy(df[df[feature] == v][target])
        for v in values
    )

    return total_entropy - weighted_entropy  # Information Gain formula

def num_to_cat(df, target_column):
    
    df = df.copy()
    
    # Handle missing values
    df = df.dropna()  # Drop rows with missing values

    # Convert numerical features to categorical bins if needed
    for col in df.columns:
        if col != target_column and df[col].dtype in ['int64', 'float64']:
            df[col] = pd.qcut(df[col], q=4, duplicates='drop')  # Binning into quartiles

    return df

if __name__ == "__main__":
    # Load dataset
    try:
        df = pd.read_csv("player_aggregated_stats.csv")
    except FileNotFoundError:
        print("Error: File 'player_aggregated_stats.csv' not found.")
        exit()

    target_column = "Consistency Score"

    # Preprocess dataset
    df = num_to_cat(df, target_column)

    # Compute entropy of the dataset
    H_S = entropy(df[target_column])
    print(f"\nEntropy of '{target_column}': {H_S:.4f}\n")

    # Compute Information Gain for each feature
    features = [col for col in df.columns if col != target_column]
    info_gains = {feature: information_gain(df, feature, target_column) for feature in features}

    # Sort features by highest Information Gain
    sorted_ig = sorted(info_gains.items(), key=lambda x: x[1], reverse=True)

    # Display results
    print("Information Gain for each feature (sorted):")
    for feature, ig in sorted_ig:
        print(f"{feature}: {ig:.4f}")
    
    # Identify the best feature for the root node
    best_feature = sorted_ig[0][0] if sorted_ig else None
    print(f"\n The best root node feature is: '{best_feature}'")
