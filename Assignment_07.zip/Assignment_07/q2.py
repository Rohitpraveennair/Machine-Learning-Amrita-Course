import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

# Load dataset
file_path = "player_aggregated_stats_cleaned.csv"
df = pd.read_csv(file_path)

# Selecting relevant features for modeling
features = [
    "Runs Scored", "Balls Faced", "Strike Rate", "Economy Rate", "Wickets Taken", 
    "Consistency Score", "Batting Impact Score", "Bowling Impact Score"
]
target = "Winning Contribution Score"

# Drop rows with missing target values
df = df.dropna(subset=[target])

# Splitting data into training and testing sets
X = df[features]
y = df[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Defining the model
rf = RandomForestRegressor()

# Hyperparameter tuning using RandomizedSearchCV
param_dist = {
    "n_estimators": [50, 100, 200, 300],
    "max_depth": [None, 10, 20, 30],
    "min_samples_split": [2, 5, 10],
    "min_samples_leaf": [1, 2, 4]
}

random_search = RandomizedSearchCV(rf, param_distributions=param_dist,n_iter=20, cv=5, scoring='neg_mean_squared_error', verbose=2, n_jobs=-1, random_state=42)

# Fitting the model
random_search.fit(X_train, y_train)

# Best parameters and model performance
best_model = random_search.best_estimator_
y_pred = best_model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"Best Parameters: {random_search.best_params_}")
print(f"Test MSE: {mse}")
