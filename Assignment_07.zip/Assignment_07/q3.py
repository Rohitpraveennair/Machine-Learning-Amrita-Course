import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

# Load dataset
file_path = "player_aggregated_stats_cleaned.csv"
df = pd.read_csv(file_path)

# Standardizing Team Names
def standardize_team_name(team):
    name_map = {
        "Royal Challengers Bangalore": "Royal Challengers Bengaluru",
        "Delhi Daredevils": "Delhi Capitals",
        "Kings XI Punjab": "Punjab Kings",
        "Gujarat Lions": None  # Remove Gujarat Lions team
    }
    return name_map.get(team, team)

df["Team"] = df["Team"].apply(standardize_team_name)

# Selecting relevant features for modeling
features = [
    "Runs Scored", "Balls Faced", "Strike Rate", "Economy Rate", "Wickets Taken", 
    "Consistency Score", "Batting Impact Score", "Bowling Impact Score"
]
target_phase = "Phase"

# Drop rows with missing values in features or target
df.replace([np.inf, -np.inf], np.nan, inplace=True)
df.dropna(subset=features + [target_phase], inplace=True)

# Convert str to int
# Ensure 'Year' column is an integer
df["Season"] = pd.to_numeric(df["Season"], errors="coerce")

# Drop any rows where Year conversion failed
df = df.dropna(subset=["Season"])
df["Season"] = df["Season"].astype(int)

# Encoding Phase as categorical
df[target_phase] = df[target_phase].astype('category').cat.codes

# Splitting data into training and testing sets
X = df[features]
y_phase = df[target_phase]
X_train, X_test, y_train_phase, y_test_phase = train_test_split(X, y_phase, test_size=0.2, random_state=42)

# Standardizing the data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Define classifiers
classifiers = {
    "Random Forest": RandomForestClassifier(n_estimators=100),
    "AdaBoost": AdaBoostClassifier(n_estimators=100),
    "XGBoost": XGBClassifier(),
    "CatBoost": CatBoostClassifier(verbose=0),
    "Naive Bayes": GaussianNB(),
    "MLP": MLPClassifier(hidden_layer_sizes=(100,), max_iter=500)
}

# Store results
results_phase = []

# Train and evaluate classifiers for Phase Classification
for name, model in classifiers.items():
    model.fit(X_train, y_train_phase)
    y_train_pred_phase = model.predict(X_train)
    y_test_pred_phase = model.predict(X_test)
    
    metrics = {
        "Model": name,
        "Train Accuracy": accuracy_score(y_train_phase, y_train_pred_phase),
        "Test Accuracy": accuracy_score(y_test_phase, y_test_pred_phase),
        "Train Precision": precision_score(y_train_phase, y_train_pred_phase, average='macro', zero_division=0),
        "Test Precision": precision_score(y_test_phase, y_test_pred_phase, average='macro', zero_division=0),
        "Train Recall": recall_score(y_train_phase, y_train_pred_phase, average='macro', zero_division=0),
        "Test Recall": recall_score(y_test_phase, y_test_pred_phase, average='macro', zero_division=0),
        "Train F1 Score": f1_score(y_train_phase, y_train_pred_phase, average='macro', zero_division=0),
        "Test F1 Score": f1_score(y_test_phase, y_test_pred_phase, average='macro', zero_division=0)
    }
    results_phase.append(metrics)

# Convert results to DataFrame
results_phase_df = pd.DataFrame(results_phase)

print("Phase Classification Results:")
print(results_phase_df)

# Filtering players who have played for the same team for at least two consecutive seasons
def filter_consistent_players(df):
    df = df.sort_values(by=["Player", "Season"])
    df["Consecutive"] = df.groupby(["Player", "Team"]).Season.diff() == 1
    df["Consecutive_Count"] = df.groupby(["Player", "Team"])['Consecutive'].cumsum()
    return df[df["Consecutive_Count"] >= 1]

df = filter_consistent_players(df)

# Selecting Best Playing XI, ensuring each player appears once based on best phase
df = df.sort_values(by=["Player", "Consistency Score"], ascending=[True, False])
df = df.drop_duplicates(subset=["Player"], keep="first")

selected_players = (
    df.sort_values(by="Consistency Score", ascending=False)
    .drop_duplicates(subset=["Team", "Player"], keep='first')
    .groupby("Team")
    .head(11)
)

# Print Playing XI for each team
print("\nSelected Playing XI for each team:")
for team in selected_players["Team"].unique():
    print(f"\n{team} Playing XI:")
    print(selected_players[selected_players["Team"] == team][["Player", "Phase", "Consistency Score"]].to_string(index=False))
