import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.feature_selection import SequentialFeatureSelector
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import AdaBoostRegressor

# Load data
file_path = 'player_aggregated_stats_cleaned.csv'
df = pd.read_csv(file_path)
df.dropna(inplace=True)

# Drop target column
df_cleaned = df.drop(columns=['Consistency Score'])

# Keep only numeric columns
X = df_cleaned.select_dtypes(include=[np.number])
y = df['Consistency Score']

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# PCA for 95% variance
pca_95 = PCA(n_components=0.95)
X_pca_95 = pca_95.fit_transform(X_scaled)

# PCA for 99% variance
pca_99 = PCA(n_components=0.99)
X_pca_99 = pca_99.fit_transform(X_scaled)

# Split data for both PCA 95% and PCA 99%
X_train_95, X_test_95, y_train_95, y_test_95 = train_test_split(X_pca_95, y, test_size=0.2, random_state=42)
X_train_99, X_test_99, y_train_99, y_test_99 = train_test_split(X_pca_99, y, test_size=0.2, random_state=42)

# Define models
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
    "SVR": SVR(),
    "Gradient Boosting": GradientBoostingRegressor(n_estimators=100, random_state=42),
    "KNN": KNeighborsRegressor(n_neighbors=5),
    "XGBoost": XGBRegressor(random_state=42),
    "AdaBoost": AdaBoostRegressor(DecisionTreeRegressor(max_depth=3), n_estimators=50)
}

# Function to train and evaluate models
def evaluate_models(X_train, X_test, y_train, y_test, models):
    results = []
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        results.append((name, r2, rmse))
        print(f"{name}:\n  R2 Score: {r2:.4f}  |  RMSE: {rmse:.4f}\n{'-'*40}")
    return results

# 1. Evaluate models on PCA-transformed data (95% and 99% variance)
print("Evaluating models on PCA 95% variance data:")
pca_95_results = evaluate_models(X_train_95, X_test_95, y_train_95, y_test_95, models)

print("\nEvaluating models on PCA 99% variance data:")
pca_99_results = evaluate_models(X_train_99, X_test_99, y_train_99, y_test_99, models)

# Sequential Feature Selection: Forward and Backward Selection
def sequential_feature_selection(X_train, X_test, y_train, y_test, models, direction='forward'):
    selector = SequentialFeatureSelector(LinearRegression(), direction=direction, n_features_to_select='auto', cv=5)
    selector.fit(X_train, y_train)
    selected_features = selector.transform(X_train)

    print(f"Selected features ({direction} selection): {selector.get_support()}")

    # Evaluate models on reduced features
    print(f"\nEvaluating models on {direction} feature selection reduced data:")
    return evaluate_models(selected_features, X_test[:, selector.get_support()], y_train, y_test, models)

# 2. Perform Forward Sequential Feature Selection for PCA 95% variance data
print("\nPerforming Forward SFS on PCA 95% variance data:")
forward_95_results = sequential_feature_selection(X_train_95, X_test_95, y_train_95, y_test_95, models, direction='forward')

# 3. Perform Backward Sequential Feature Selection for PCA 95% variance data
print("\nPerforming Backward SFS on PCA 95% variance data:")
backward_95_results = sequential_feature_selection(X_train_95, X_test_95, y_train_95, y_test_95, models, direction='backward')

# 4. Perform Forward Sequential Feature Selection for PCA 99% variance data
print("\nPerforming Forward SFS on PCA 99% variance data:")
forward_99_results = sequential_feature_selection(X_train_99, X_test_99, y_train_99, y_test_99, models, direction='forward')

# 5. Perform Backward Sequential Feature Selection for PCA 99% variance data
print("\nPerforming Backward SFS on PCA 99% variance data:")
backward_99_results = sequential_feature_selection(X_train_99, X_test_99, y_train_99, y_test_99, models, direction='backward')

# Optional: Plot Comparison of Results
def plot_comparison(results1, results2, results3, results4, results5, results6, label1, label2, label3, label4, label5, label6):
    model_names = [r[0] for r in results1]
    
    r2_scores1 = [r[1] for r in results1]
    rmse_scores1 = [r[2] for r in results1]
    
    r2_scores2 = [r[1] for r in results2]
    rmse_scores2 = [r[2] for r in results2]
    
    r2_scores3 = [r[1] for r in results3]
    rmse_scores3 = [r[2] for r in results3]
    
    r2_scores4 = [r[1] for r in results4]
    rmse_scores4 = [r[2] for r in results4]
    
    r2_scores5 = [r[1] for r in results5]
    rmse_scores5 = [r[2] for r in results5]
    
    r2_scores6 = [r[1] for r in results6]
    rmse_scores6 = [r[2] for r in results6]

    plt.figure(figsize=(14, 7))

    # R² Score Comparison
    plt.subplot(1, 2, 1)
    plt.barh(model_names, r2_scores1, label=label1, alpha=0.6)
    plt.barh(model_names, r2_scores2, label=label2, alpha=0.6)
    plt.barh(model_names, r2_scores3, label=label3, alpha=0.6)
    plt.barh(model_names, r2_scores4, label=label4, alpha=0.6)
    plt.barh(model_names, r2_scores5, label=label5, alpha=0.6)
    plt.barh(model_names, r2_scores6, label=label6, alpha=0.6)
    plt.xlabel("R² Score")
    plt.title("Model Comparison - R²")
    plt.legend()

    # RMSE Comparison
    plt.subplot(1, 2, 2)
    plt.barh(model_names, rmse_scores1, label=label1, alpha=0.6)
    plt.barh(model_names, rmse_scores2, label=label2, alpha=0.6)
    plt.barh(model_names, rmse_scores3, label=label3, alpha=0.6)
    plt.barh(model_names, rmse_scores4, label=label4, alpha=0.6)
    plt.barh(model_names, rmse_scores5, label=label5, alpha=0.6)
    plt.barh(model_names, rmse_scores6, label=label6, alpha=0.6)
    plt.xlabel("RMSE")
    plt.title("Model Comparison - RMSE")
    plt.legend()

    plt.tight_layout()
    plt.show()

# Plot Comparison of PCA (95% vs 99%) and SFS (Forward and Backward)
plot_comparison(
    pca_95_results, pca_99_results, forward_95_results, backward_95_results, forward_99_results, backward_99_results,
    'PCA 95% Variance', 'PCA 99% Variance', 'Forward SFS 95%', 'Backward SFS 95%', 'Forward SFS 99%', 'Backward SFS 99%'
)
