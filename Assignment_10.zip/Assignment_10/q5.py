import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
import lime
import lime.lime_tabular
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load dataset
df = pd.read_csv("player_aggregated_stats_cleaned.csv")
df.dropna(inplace=True)

# Separate target and features
X = df.drop(columns=["Consistency Score"])
X = X.select_dtypes(include=[np.number])  # Keep only numeric features
y = df["Consistency Score"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train model
model = GradientBoostingRegressor(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# Evaluate model
y_pred = model.predict(X_test_scaled)
r2 = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\nModel Performance:\n  R²: {r2:.4f} | RMSE: {rmse:.4f}")

# ----------------------------
# LIME Explanation
# ----------------------------
explainer_lime = lime.lime_tabular.LimeTabularExplainer(
    training_data=X_train_scaled,
    feature_names=X.columns.tolist(),
    mode="regression",
    random_state=42
)

# Explain one instance
instance = X_test_scaled[0]
exp = explainer_lime.explain_instance(instance, model.predict, num_features=10)

print("\n🔍 LIME Explanation for a Single Instance")
print(f"Intercept: {exp.intercept[0]}")
print(f"Predicted Value: {exp.predicted_value}")
print(f"Explanation Score: {exp.score:.4f}")

# Show LIME explanation (textual)
exp.as_list()

# ----------------------------
# SHAP Explanation
# ----------------------------
explainer_shap = shap.Explainer(model.predict, X_train_scaled)
shap_values = explainer_shap(X_test_scaled)

print("\n🔍 SHAP Explanation (Global and Local)")

# Global Feature Importance
shap.plots.beeswarm(shap_values, max_display=10)

# Waterfall Plot for 1st instance
shap.plots.waterfall(shap_values[0])
