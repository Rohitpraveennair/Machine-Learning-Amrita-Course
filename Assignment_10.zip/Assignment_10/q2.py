import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error, r2_score

# Regression models
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from sklearn.tree import DecisionTreeRegressor

# 1. Load and clean data
def load_and_clean_data(file_path):
    """Load data from CSV, drop missing values, and prepare features and target."""
    df = pd.read_csv(file_path)
    df.dropna(inplace=True)
    df_cleaned = df.drop(columns=['Consistency Score'])
    X = df_cleaned.select_dtypes(include=[np.number])
    y = df['Consistency Score']
    return X, y

# 2. Scale features
def scale_features(X):
    """Scale features using StandardScaler."""
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled

# 3. Apply PCA
def apply_pca(X_scaled, variance_threshold=0.99):
    """Apply PCA to the scaled features to retain specified variance."""
    pca = PCA(n_components=variance_threshold)
    X_pca = pca.fit_transform(X_scaled)
    return X_pca, pca

# 4. Plot explained variance
def plot_explained_variance(pca):
    """Plot cumulative explained variance by PCA components."""
    plt.figure(figsize=(8, 5))
    plt.plot(np.cumsum(pca.explained_variance_ratio_), marker='o')
    plt.xlabel('Number of Components')
    plt.ylabel('Cumulative Explained Variance')
    plt.title('PCA Explained Variance')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# 5. Split data into training and testing sets
def split_data(X_pca, y, test_size=0.2, random_state=42):
    """Split the data into training and testing sets."""
    X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=test_size, random_state=random_state)
    return X_train, X_test, y_train, y_test

# 6. Define models
def define_models():
    """Define and return a dictionary of regression models."""
    base_regressor = DecisionTreeRegressor(max_depth=3)
    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
        "SVR": SVR(),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=100, random_state=42),
        "KNN": KNeighborsRegressor(n_neighbors=5),
        "XGBoost": XGBRegressor(random_state=42),
        "AdaBoost": AdaBoostRegressor(base_regressor, n_estimators=50)
    }
    return models

# 7. Train and evaluate models
def train_and_evaluate_models(models, X_train, y_train, X_test, y_test):
    """Train each model and evaluate performance using R² and RMSE."""
    results = []
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        results.append((name, r2, rmse))
        print(f"{name}:\n  R2 Score: {r2:.4f}  |  RMSE: {rmse:.4f}\n{'-'*40}")
    return results

# 8. Plot model comparison
def plot_model_comparison(results):
    """Plot comparison of R² scores for all models."""
    model_names = [r[0] for r in results]
    r2_scores = [r[1] for r in results]
    
    plt.figure(figsize=(10, 5))
    plt.barh(model_names, r2_scores, color='skyblue')
    plt.xlabel("R² Score")
    plt.title("Model Comparison - R² with PCA Features")
    plt.grid(True, axis='x')
    plt.tight_layout()
    plt.show()

# Main function to tie everything together
def main(file_path='player_aggregated_stats_cleaned.csv'):
    """Main function to load data, apply PCA, train models, and plot results."""
    # Step 1: Load and prepare data
    X, y = load_and_clean_data(file_path)
    
    # Step 2: Scale features
    X_scaled = scale_features(X)
    
    # Step 3: Apply PCA
    X_pca, pca = apply_pca(X_scaled, variance_threshold=0.95)  # Set to 0.95 explained variance
    
    # Step 4: Plot explained variance
    plot_explained_variance(pca)
    
    # Step 5: Split data into train/test
    X_train, X_test, y_train, y_test = split_data(X_pca, y)
    
    # Step 6: Define models
    models = define_models()
    
    # Step 7: Train and evaluate models
    results = train_and_evaluate_models(models, X_train, y_train, X_test, y_test)
    
    # Step 8: Plot comparison of models
    plot_model_comparison(results)

# Run the main function
if __name__ == "__main__":
    main()
