import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
file_path = 'player_aggregated_stats_cleaned.csv'
df = pd.read_csv(file_path)

# Compute the correlation matrix
correlation_matrix = df.corr(numeric_only=True)

# Set the figure size
plt.figure(figsize=(12, 10))

# Create the heatmap
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm', square=True, linewidths=0.5)

# Add a title
plt.title('Feature Correlation Heatmap')

# Show the plot
plt.tight_layout()
plt.show()
