from q2 import main

# Run the main function with PCA explained variance set to 0.95
if __name__ == "__main__":
    main(file_path='player_aggregated_stats_cleaned.csv')
